DOORS JOURNAL — ANDROID STARTER PROJECT

This is a fan-made Android app project, not an already compiled APK.
It includes:
- Entity journal for Rush, Ambush, Screech, Seek, Eyes, Halt, Figure, and Guiding Light
- Search
- Mark discovered / unmark discovered
- Local progress saved on the device
- Survival tips

HOW TO BUILD AN APK
1. On a computer, install Android Studio from the official Android developer website.
2. Unzip this folder.
3. In Android Studio choose Open and select the DoorsJournal folder.
4. Wait for Gradle sync. If prompted, install Android SDK Platform 35.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When it finishes, click the link in the notification to locate the APK.

IMPORTANT
- This starter project has not been compiled or tested on a real device.
- It does not include official Roblox artwork or copyrighted game images.
- App name and characters are used for an unofficial fan reference only.
- You need a computer with Android Studio to compile this project as an APK.
